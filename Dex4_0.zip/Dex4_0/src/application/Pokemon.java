package application;

import java.util.ArrayList;
import java.util.Collection;

public class Pokemon {
    private String name;
    private int id;
    private ArrayList<Type> types;
    private int hp;
    private int attack;
    private int defense;
    private int specialAttack;
    private int specialDefense;
    private int speed;

    public Pokemon(String name, int id, Type type1, Type type2, int hp, int attack, int defense, int specialAttack, int specialDefense, int speed) {
        this.name = name;
        this.id = id;
        this.types = new ArrayList<>();
        this.types.add(type1);
        if (type2 != null) {
            this.types.add(type2);
        }
        this.hp = hp;
        this.attack = attack;
        this.defense = defense;
        this.specialAttack = specialAttack;
        this.specialDefense = specialDefense;
        this.speed = speed;
    }

    // getter methods for all the instance variables
    public String getName() {
        return name;
    }

    public int getId() {
        return id;
    }

    public ArrayList<Type> getTypes() {
        return types;
    }

    public int getHp() {
        return hp;
    }

    public int getAttack() {
        return attack;
    }

    public int getDefense() {
        return defense;
    }

    public int getSpecialAttack() {
        return specialAttack;
    }

    public int getSpecialDefense() {
        return specialDefense;
    }

    public int getSpeed() {
        return speed;
    }

	public static Collection<Pokemon> getAllPokemon() {
		// TODO Auto-generated method stub
		return null;
	}
}

