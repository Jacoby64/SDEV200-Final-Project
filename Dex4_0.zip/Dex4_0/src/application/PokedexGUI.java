package application;
	
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class PokedexGUI extends Application {

    // create an ArrayList to hold all the Pokemon objects
    private ArrayList<Pokemon> pokemonList = new ArrayList<>();

    // create a method to add Pokemon objects to the ArrayList
    private void addPokemon(Pokemon pokemon) {
        pokemonList.add(pokemon);
        
    }
    
    private GridPane gridPane = new GridPane();
	private ComboBox<Type> pokemonTable;
	private ObservableList<Pokemon> pokemonObservableList = FXCollections.observableArrayList();
	
    
    @Override
    public void start(Stage primaryStage) throws Exception{
    	
        
        gridPane.setPadding(new Insets(10, 10, 10, 10));
        gridPane.setHgap(10);
        gridPane.setVgap(10);
        
        // create labels for the Pokemon data and add them to the GridPane
        gridPane.add(new Label("Name"), 0, 0);
        gridPane.add(new Label("ID"), 1, 0);
        gridPane.add(new Label("Type"), 2, 0);
        gridPane.add(new Label("HP"), 3, 0);
        gridPane.add(new Label("Attack"), 4, 0);
        gridPane.add(new Label("Defense"), 5, 0);
        gridPane.add(new Label("Special Attack"), 6, 0);
        gridPane.add(new Label("Special Defense"), 7, 0);
        gridPane.add(new Label("Speed"), 8, 0);

        // loop through the Pokemon objects and add their data to the GridPane
        int rowIndex = 1;
        for (Pokemon pokemon : pokemonList) {
            gridPane.add(new Label(pokemon.getName()), 0, rowIndex);
            gridPane.add(new Label(String.valueOf(pokemon.getId())), 1, rowIndex);
            gridPane.add(new Label(pokemon.getTypes().toString()), 2, rowIndex);
            gridPane.add(new Label(String.valueOf(pokemon.getHp())), 3, rowIndex);
            gridPane.add(new Label(String.valueOf(pokemon.getAttack())), 4, rowIndex);
            gridPane.add(new Label(String.valueOf(pokemon.getDefense())), 5, rowIndex);
            gridPane.add(new Label(String.valueOf(pokemon.getSpecialAttack())), 6, rowIndex);
            gridPane.add(new Label(String.valueOf(pokemon.getSpecialDefense())), 7, rowIndex);
            gridPane.add(new Label(String.valueOf(pokemon.getSpeed())), 8, rowIndex);
            rowIndex++;
            
        }
        
        
        ComboBox<Type> typeComboBox = new ComboBox<>(FXCollections.observableArrayList(Type.values()));
        typeComboBox.setOnAction(event -> {
            Type selectedType = typeComboBox.getSelectionModel().getSelectedItem();
            filterByType(selectedType);
        });


        
        TextField searchBar = new TextField();
        searchBar.setPromptText("Search by name or ID");
        
        Button searchButton = new Button("Search");
        searchButton.setOnAction(e -> handleSearch(searchBar.getText()));
        
        // create a scroll pane and add the grid pane to it
        ScrollPane scrollPane = new ScrollPane();
        scrollPane.setContent(gridPane);
        
        // create a VBox to hold the title, search bar, and the scroll pane
        VBox vbox = new VBox();
        vbox.setSpacing(10);

        // create a search bar for the user to search by name or ID number of the Pokemon object
        Image icon = new Image("Pokedex.png");
        HBox titleBox = new HBox();
        titleBox.setSpacing(10);
        titleBox.setAlignment(Pos.CENTER_LEFT);
        ImageView logo = new ImageView(icon);
        logo.setFitHeight(50);
        logo.setFitWidth(200);
        titleBox.getChildren().addAll(searchBar, searchButton, logo, typeComboBox);
		
		
        vbox.getChildren().addAll(titleBox, scrollPane);

        
        

        

        

        
        
        
    	addPokemon(new Pokemon("Bulbasaur", 1, Type.GRASS, Type.POISON, 45, 49, 49, 65, 65, 45));
    	addPokemon(new Pokemon("Ivysaur", 2, Type.GRASS, Type.POISON, 60, 62, 63, 80, 80, 60));
    	addPokemon(new Pokemon("Venusaur", 3, Type.GRASS, Type.POISON, 80, 82, 83, 100, 100, 80));
    	addPokemon(new Pokemon("Charmander", 4, Type.FIRE, null, 39, 52, 43, 60, 50, 65));
    	addPokemon(new Pokemon("Charmeleon", 5, Type.FIRE, null, 58, 64, 58, 80, 65, 80));
    	addPokemon(new Pokemon("Charizard", 6, Type.FIRE, Type.FLYING, 78, 84, 78, 109, 85, 100));
    	addPokemon(new Pokemon("Squirtle", 7, Type.WATER,null,44, 48, 65, 50, 64, 43));
    	addPokemon(new Pokemon("Wartortle", 8, Type.WATER,null, 59, 63, 80, 65, 80, 58));
    	addPokemon(new Pokemon("Blastoise", 9, Type.WATER,null, 79, 83, 100, 85, 105, 78));
    	addPokemon(new Pokemon("Caterpie", 10, Type.BUG,null, 45, 30, 35, 20, 20, 45));
    	addPokemon(new Pokemon("Metapod", 11, Type.BUG,null, 50,	20,	55,	25,	25,	30));
    	addPokemon(new Pokemon("Butterfree", 12, Type.BUG,Type.FLYING, 60, 45, 50, 90, 80, 70));
    	addPokemon(new Pokemon("Weedle", 13, Type.BUG,Type.POISON, 40, 35, 30, 20, 20, 50));
    	addPokemon(new Pokemon("Kakuna", 14, Type.BUG,Type.POISON, 45, 25, 50, 25, 25, 35));
    	addPokemon(new Pokemon("Beedrill", 15, Type.BUG,Type.POISON, 65, 90, 40, 45, 80, 75));
    	addPokemon(new Pokemon("Pidgey", 16, Type.FLYING, Type.NORMAL, 40,	45,	40,	35,	35,	56));
    	addPokemon(new Pokemon("Pidgeotto", 17, Type.FLYING, Type.NORMAL, 63,	60,	55,	50,	50,	71));
    	addPokemon(new Pokemon("Pidgeot", 18, Type.FLYING, Type.NORMAL, 83,	80,	75,	70,	70,	101));
    	addPokemon(new Pokemon("Rattata", 19, Type.NORMAL, null, 30,	56,	35,	25,	35,	72));
    	addPokemon(new Pokemon("Raticate", 20, Type.NORMAL, null, 55,	81,	60,	50,	70,	97));
    	addPokemon(new Pokemon("Spearow", 21, Type.FLYING, Type.NORMAL, 40,	60,	30,	31,	31,	70));
    	addPokemon(new Pokemon("Fearow", 22, Type.FLYING, Type.NORMAL, 65,	90,	65,	61,	61,	100));
    	addPokemon(new Pokemon("Ekans", 23, Type.POISON, null,35,	60,	44,	40,	54,	55));
    	addPokemon(new Pokemon("Arbok", 24, Type.POISON, null,60,	95,	69,	65,	79,	80));
    	addPokemon(new Pokemon("Pikachu", 25, Type.ELECTRIC, null,35,	55,	40,	50,	50,	90));
    	addPokemon(new Pokemon("Raichu", 26, Type.ELECTRIC, null,60,	90,	55,	90,	80,	110));
    	addPokemon(new Pokemon("Sandshrew", 27, Type.GROUND, null,50,	75,	85,	20,	30,	40));
    	addPokemon(new Pokemon("Sandslash", 28, Type.GROUND, null,75,	100,	110,	45,	55,	65));
    	addPokemon(new Pokemon("Nidoran♀", 29, Type.POISON, null,55, 47, 52, 40, 40, 41));
    	addPokemon(new Pokemon("Nidorina", 30, Type.POISON, null,70,	62,	67,	55,	55,	56 ));
    	addPokemon(new Pokemon("Nidoqueen", 31, Type.POISON, Type.GROUND,90,	92,	87,	75,	85,	76));
    	addPokemon(new Pokemon("Nidoran♂", 32, Type.POISON, null,46,	57,	40,	40,	40,	50));
    	addPokemon(new Pokemon("Nidorino", 33, Type.POISON, null,61,	72,	57,	55,	55,	65));
    	addPokemon(new Pokemon("Nidoking", 34, Type.POISON, Type.GROUND,81,	102,	77,	85,	75,	85));
    	addPokemon(new Pokemon("Clefairy", 35, Type.NORMAL, null,70,	45,	48,	60,	65,	35));
    	addPokemon(new Pokemon("Clefable", 36, Type.NORMAL, null,95,	70,	73,	95,	90,	60));
    	addPokemon(new Pokemon("Vulpix", 37, Type.FIRE, null,38,	41,	40,	50,	65,	65));
    	addPokemon(new Pokemon("Ninetails", 38, Type.FIRE, null,73,	76,	75,	81,	100,	100));
    	addPokemon(new Pokemon("Jigglypuff", 39, Type.NORMAL, null,115,	45,	20,	45,	25,	20));
    	addPokemon(new Pokemon("Wigglytuff", 40, Type.NORMAL, null,140,	70,	45,	85,	50,	45));
    	addPokemon(new Pokemon("Zubat", 41, Type.FLYING, Type.POISON,40,	45,	35,	30,	40,	55));
    	addPokemon(new Pokemon("Golbat", 42, Type.FLYING, Type.POISON,75,	80,	70,	65,	75,	90));
    	addPokemon(new Pokemon("Oddish", 43,  Type.GRASS, Type.POISON,45,	50,	55,	75,	65,	30));
	    addPokemon(new Pokemon("Gloom", 44,  Type.GRASS, Type.POISON,60,	65,	70,	85,	75,	40));
	    addPokemon(new Pokemon("Vileplume", 45,  Type.GRASS, Type.POISON,75,	80,	85,	110,	90,	50));
	    addPokemon(new Pokemon("Paras", 46, Type.BUG, Type.GRASS,35,	70,	55,	45,	55,	25));
	    addPokemon(new Pokemon("Parasect", 47, Type.BUG, Type.GRASS,60,	95,	80,	60,	80,	30));
	    addPokemon(new Pokemon("Venonat", 48, Type.BUG, Type.POISON,60,	55,	50,	40,	55,	45));
	    addPokemon(new Pokemon("Venomoth", 49, Type.BUG, Type.POISON,70,	65,	60,	90,	75,	90));
	    addPokemon(new Pokemon("Diglett", 50, Type.GROUND,null, 10,	55,	25,	35,	45,	95));
	    addPokemon(new Pokemon("Dugtrio", 51, Type.GROUND, null,35,	100,	50,	50,	70,	120));
	    addPokemon(new Pokemon("Meowth", 52, Type.NORMAL, null,40,	45,	35,	40,	40,	90));
	    addPokemon(new Pokemon("Persian", 53, Type.NORMAL, null,65,	70,	60,	65,	65,	115));
	    addPokemon(new Pokemon("Psyduck", 54, Type.WATER,null, 50,	52,	48,	65,	50,	55));
	    addPokemon(new Pokemon("Golduck", 55, Type.WATER,null, 80,	82,	78,	95,	80,	85));
	    addPokemon(new Pokemon("Mankey", 56, Type.FIGHTING,null, 40,	80,	35,	35,	45,	70));
	    addPokemon(new Pokemon("Primeape", 57, Type.FIGHTING, null,65,	105,	60,	60,	70,	95));
	    addPokemon(new Pokemon("Growlithe", 58, Type.FIRE, null,55,	70,	45,	70,	50,	60));
	    addPokemon(new Pokemon("Arcanine", 59, Type.FIRE, null,90,	110,	80,	100,	80,	95));
	    addPokemon(new Pokemon("Poliwag", 60, Type.WATER, null,40,	50,	40,	40,	40,	90));
	    addPokemon(new Pokemon("Poliwhirl", 61, Type.WATER,null, 65,	65,	65,	50,	50,	90));
	    addPokemon(new Pokemon("Poliwrath", 62, Type.WATER,Type.FIGHTING, 90,	95,	95,	70,	90,	70));
	    addPokemon(new Pokemon("Abra", 63, Type.PSYCHIC, null,90,	95,	95,	70,	90,	70));
	    addPokemon(new Pokemon("Kadabra", 64, Type.PSYCHIC, null,40,	35,	30,	120,	70,	105));
	    addPokemon(new Pokemon("Alakazam", 65,  Type.PSYCHIC, null,55,	50,	45,	135,	95,	120));
	    addPokemon(new Pokemon("Machop", 66, Type.FIGHTING, null,70,	80,	50,	35,	35,	35));
	    addPokemon(new Pokemon("Machoke", 67, Type.FIGHTING, null,80,	100,	70,	50,	60,	45));
	    addPokemon(new Pokemon("Machamp", 68,  Type.FIGHTING, null,90,	130,	80,	65,	85,	55));
	    addPokemon(new Pokemon("Bellsprout", 69, Type.GRASS, Type.POISON,50,	75,	35,	70,	30,	40));
	    addPokemon(new Pokemon("Weepinbell", 70, Type.GRASS,Type.POISON, 65,	90,	50,	85,	45,	55));
	    addPokemon(new Pokemon("Victreebel", 71,  Type.GRASS, Type.POISON,80,	105,	65,	100,	70,	70));
	    addPokemon(new Pokemon("Tentacool", 72,  Type.WATER, Type.POISON,40,	40,	35,	50,	100,	70));
	    addPokemon(new Pokemon("Tentacruel", 73, Type.WATER, Type.POISON,80,	70,	65,	80,	120,	100));
	    addPokemon(new Pokemon("Geodude", 74,  Type.ROCK, Type.GROUND,40,	80,	100, 30,	30,	20));
	    addPokemon(new Pokemon("Graveler", 75,  Type.ROCK, Type.GROUND,55,	95,	115,	45,	45,	35));
	    addPokemon(new Pokemon("Golem", 76,  Type.ROCK, Type.GROUND,80,	120,	130,	55,	65,	45));
	    addPokemon(new Pokemon("Ponyta", 77,  Type.FIRE,null, 50,	85,	55,	65,	65,	90));
	    addPokemon(new Pokemon("Rapidash", 78,  Type.FIRE,null, 65,	100,	70,	80,	80,	105));
	    addPokemon(new Pokemon("Slowpoke", 79, Type.WATER, Type.PSYCHIC,90,	65,	65,	40,	40,	15));
	    addPokemon(new Pokemon("Slowbro", 80, Type.WATER,Type.PSYCHIC, 95,	75,	110,	100,	80,	30));
	    addPokemon(new Pokemon("Magnemite", 81, Type.ELECTRIC, null,25,	35,	70,	95,	55,	45));
	    addPokemon(new Pokemon("Magneton", 82, Type.ELECTRIC, null,50,	60,	95,	120,	70,	70));
	    addPokemon(new Pokemon("Farfetch'd", 83, Type.FLYING, Type.NORMAL,52,	90,	55,	58,	62,	60));
	    addPokemon(new Pokemon("Doduo", 84, Type.FLYING, Type.NORMAL,35,	85,	45,	35,	35,	75));
	    addPokemon(new Pokemon("Dodrio", 85, Type.FLYING, Type.NORMAL,60,	110,	70,	60,	60,	110));
	    addPokemon(new Pokemon("Seel", 86, Type.WATER, null,65,	45,	55,	45,	70,	45));
	    addPokemon(new Pokemon("Dewgong", 87, Type.ICE, Type.WATER,90,	70,	80,	70,	95,	70));
	    addPokemon(new Pokemon("Grimer", 88, Type.POISON, null,80,	80,	50,	40,	50,	25));
	    addPokemon(new Pokemon("Muk", 89, Type.POISON, null,105,	105,	75,	65,	100,	50));
	    addPokemon(new Pokemon("Shellder", 90, Type.ICE, Type.WATER,30,	65,	100,	45,	25,	40));
	    addPokemon(new Pokemon("Cloyster", 91, Type.ICE, Type.WATER,50,	95,	180,	85,	45,	70));
	    addPokemon(new Pokemon("Gastly", 92, Type.GHOST, Type.POISON,30,	35,	30,	100,	35,	80));
	    addPokemon(new Pokemon("Haunter", 93, Type.GHOST, Type.POISON,30,	35,	30,	100,	35,	80));
	    addPokemon(new Pokemon("Gengar", 94, Type.GHOST, Type.POISON,60,	65,	60,	130, 75, 110));
	    addPokemon(new Pokemon("Onix", 95, Type.ROCK, Type.GROUND,35,	45,	160,	30,	45,	70));
	    addPokemon(new Pokemon("Drowzee", 96, Type.PSYCHIC, null,60,	48,	45,	43,	90,	42));
	    addPokemon(new Pokemon("Hypno", 97, Type.PSYCHIC, null,85,	73,	70,	73,	115,	67));
	    addPokemon(new Pokemon("Krabby", 98, Type.WATER, null,30,	105,	90,	25,	25,	50));
	    addPokemon(new Pokemon("Kingler", 99, Type.WATER, null,55,	130,	115,	50,	50,	75));
	    addPokemon(new Pokemon("Voltorb", 100, Type.ELECTRIC, null,40,	30,	50,	55,	55,	100));
	    addPokemon(new Pokemon("Electrode", 101, Type.ELECTRIC, null,60,	50,	70,	80,	80,	150));
	    addPokemon(new Pokemon("Exeggcute", 102, Type.GRASS, Type.PSYCHIC,60,	40,	80,	60,	45,	40));
	    addPokemon(new Pokemon("Exeggutor", 103, Type.GRASS, Type.PSYCHIC,95,	95,	85,	125,	75,	55));
	    addPokemon(new Pokemon("Cubone", 104, Type.GROUND, null,50,	50,	95,	40,	50,	35));
	    addPokemon(new Pokemon("Marowak", 105, Type.GROUND, null,60,	80,	110,	50,	80,	45));
	    addPokemon(new Pokemon("Hitmonlee", 106, Type.FIGHTING, null,50,	120,	53,	35,	110,	87));
	    addPokemon(new Pokemon("Hitmonchan", 107, Type.FIGHTING, null,50,	105,	79,	35,	110,	76));
	    addPokemon(new Pokemon("Lickitung", 108, Type.NORMAL, null,90,	55,	75,	60,	75,	30));
	    addPokemon(new Pokemon("Koffing", 109, Type.POISON, null,40,	65,	95,	60,	45,	35));
	    addPokemon(new Pokemon("Weezing", 110, Type.POISON, null,65,	90,	120,	85,	70,	60));
	    addPokemon(new Pokemon("Rhyhorn", 111, Type.ROCK, Type.GROUND,80,	85,	95,	30,	30,	25));
	    addPokemon(new Pokemon("Rhydon", 112, Type.ROCK, Type.GROUND,105,	130,	120,	45,	45,	40));
	    addPokemon(new Pokemon("Chansey", 113, Type.NORMAL,null, 250,	5,	5,	35,	105,	50));
	    addPokemon(new Pokemon("Tangela",114, Type.GRASS, null,65,	55,	115,	100,	40,	60));
	    addPokemon(new Pokemon("Kangaskhan", 115, Type.NORMAL, null,105,	95,	80,	40,	80,	90));
	    addPokemon(new Pokemon("Horsea", 116, Type.WATER, null,30,	40,	70,	70,	25,	60));
	    addPokemon(new Pokemon("Seadra", 117, Type.WATER, null,55,	65,	95,	95,	45,	85));
	    addPokemon(new Pokemon("Goldeen", 118, Type.WATER, null,45,	67,	60,	35,	50,	63));
	    addPokemon(new Pokemon("Seaking", 119, Type.WATER, null,80,	92,	65,	65,	80, 68));
	    addPokemon(new Pokemon("Staryu", 120, Type.WATER, null,30,	45,	55,	70,	55,	85));
	    addPokemon(new Pokemon("Starmie", 121, Type.WATER, Type.PSYCHIC,60,	75,	85,	100,	85,	115));
	    addPokemon(new Pokemon("Mr. Mime", 122, Type.PSYCHIC, null,40,	45,	65,	100,	120,	90));
	    addPokemon(new Pokemon("Scyther", 123, Type.BUG, Type.FLYING,70,	110,	80,	55,	80,	105));
	    addPokemon(new Pokemon("Jynx", 124, Type.ICE, Type.PSYCHIC,65,	50,	35,	115, 95,	95));
	    addPokemon(new Pokemon("Electabuzz", 125, Type.ELECTRIC, null,65,	83,	57,	95,	85,	105));
	    addPokemon(new Pokemon("Magmar", 126, Type.FIRE, null,65,	95,	57,	100,	85,	93));
	    addPokemon(new Pokemon("Pinsir", 127, Type.BUG, null,65,	125,	100,	55,	70,	85));
	    addPokemon(new Pokemon("Tauros", 128, Type.NORMAL, null,75,	100,	95,	40,	70,	110));
	    addPokemon(new Pokemon("Magikarp", 129, Type.WATER, null,20,	10,	55,	15,	20,	80));
	    addPokemon(new Pokemon("Gyarados", 130, Type.WATER, Type.FLYING,95,	125,	79,	60,	100,	81));
	    addPokemon(new Pokemon("Lapras", 131, Type.WATER, Type.ICE,130,	85,	80,	85,	95,	60));
	    addPokemon(new Pokemon("Ditto", 132, Type.NORMAL, Type.ICE,48,	48,	48,	48,	48,	48));
	    addPokemon(new Pokemon("Eevee", 133, Type.NORMAL, Type.ICE,55,	55,	50,	45,	65,	55));
	    addPokemon(new Pokemon("Vaporeon", 134, Type.WATER, Type.ICE,130,	65,	60,	110,	95,	65));
	    addPokemon(new Pokemon("Jolteon", 135, Type.ELECTRIC, Type.ICE,65,	65,	60,	110,	95,	130));
	    addPokemon(new Pokemon("Flareon", 136, Type.FIRE, Type.ICE,65,	130,	60,	95,	110,	65));
	    addPokemon(new Pokemon("Porygon", 137, Type.NORMAL, Type.ICE,65,	60,	70,	85,	75,	40));
	    addPokemon(new Pokemon("Omanyte", 138, Type.WATER, Type.ROCK,35,	40,	100,	90,	55,	35));
	    addPokemon(new Pokemon("Omastar", 139, Type.WATER, Type.ROCK,70,	60,	125,	115,	70,	55));
	    addPokemon(new Pokemon("Kabuto", 140, Type.WATER, Type.ROCK,30,	80,	90,	55,	45,	55));
	    addPokemon(new Pokemon("Kabutops", 141, Type.WATER, Type.ROCK,60,	115,	105,	65,	70,	80));
	    addPokemon(new Pokemon("Aerodactyl", 142, Type.ROCK, Type.FLYING,80,	105,	65,	60,	75,	130));
	    addPokemon(new Pokemon("Snorlax", 143, Type.NORMAL, null,160,	110,	65,	65,	110,	30));
	    addPokemon(new Pokemon("Articuno", 144, Type.ICE, Type.FLYING,90,	85,	100,	95,	125,	85));
	    addPokemon(new Pokemon("Zapdos", 145, Type.ELECTRIC, Type.FLYING,90,	90,	85,	125,	90,	100));
	    addPokemon(new Pokemon("Moltres", 146, Type.FIRE, Type.FLYING,90,	100,	90,	125,	85,	90));
	    addPokemon(new Pokemon("Dratini", 147, Type.DRAGON, null,41,	64,	45,	50,	50,	50));
	    addPokemon(new Pokemon("Dragonair", 148, Type.DRAGON, null,61,	84,	65,	70,	70,	70));
	    addPokemon(new Pokemon("Dragonite", 149, Type.DRAGON, Type.FLYING,91,	134,	95,	100,	100,	80));
	    addPokemon(new Pokemon("Mewtwo", 150, Type.PSYCHIC, null,106,	110,	90,	154,	90,	130));
	    addPokemon(new Pokemon("Mew", 151, Type.PSYCHIC, null,100,	100,	100,	100,	100,	100));
 

         // set the scene and show the stage
         Scene scene = new Scene(vbox, 600, 400);
         primaryStage.setScene(scene);
         primaryStage.getIcons().add(new Image("Pokeball.png"));
         primaryStage.getIcons().add(icon);
         primaryStage.setTitle("");
         primaryStage.show();
         
    }
	public static void main(String[] args) {
		launch(args);
	}
	
	private void handleSearch(String searchTerm) {
	    List<Pokemon> filteredList = pokemonList.stream()
	            .filter(pokemon -> pokemon.getName().toLowerCase().contains(searchTerm.toLowerCase())
	                    || String.valueOf(pokemon.getId()).contains(searchTerm))
	            .collect(Collectors.toList());
	    updateGridPane(filteredList);
	}
	
    private void updateGridPane(List<Pokemon> pokemonList) {
		gridPane.getChildren().clear();

    	// add labels to the GridPane for each Pokemon object in the filtered list
    	int rowIndex = 0;
    	for (Pokemon pokemon : pokemonList) {
    	    gridPane.addRow(rowIndex++,
    	            new Label(pokemon.getName()),
    	            new Label(String.valueOf(pokemon.getId())),
    	            new Label(pokemon.getTypes().toString()),
    	            new Label(String.valueOf(pokemon.getHp())),
    	            new Label(String.valueOf(pokemon.getAttack())),
    	            new Label(String.valueOf(pokemon.getDefense())),
    	            new Label(String.valueOf(pokemon.getSpecialAttack())),
    	            new Label(String.valueOf(pokemon.getSpecialDefense())),
    	            new Label(String.valueOf(pokemon.getSpeed())));
    	}
    }
    

    

    
    private void filterByType(Type type) {
        List<Pokemon> filteredList = new ArrayList<>();
        for (Pokemon pokemon : pokemonList) {
            if (pokemon.getTypes().contains(type)) {
                filteredList.add(pokemon);
            }
        }
        pokemonObservableList.setAll(filteredList);
    }
}